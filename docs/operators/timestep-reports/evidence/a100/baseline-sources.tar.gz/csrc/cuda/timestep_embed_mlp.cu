// SPDX-License-Identifier: Apache-2.0
// Fixed-tile FP32 primitives. No atomic reductions or shape-dependent dispatch.
#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <c10/cuda/CUDAGuard.h>
#include <c10/cuda/CUDAException.h>

namespace {
constexpr int T = 16;
__global__ void timestep_mm(const float* a, const float* b, float* c,
                           int m, int n, int k, int64_t as0, int64_t as1,
                           int64_t bs0, int64_t bs1) {
    __shared__ float aa[T][T], bb[T][T];
    int x = threadIdx.x, y = threadIdx.y;
    int row = blockIdx.y * T + y, col = blockIdx.x * T + x;
    float acc = 0.f;
    for (int base = 0; base < k; base += T) {
        aa[y][x] = row < m && base+x < k ? a[row*as0+(base+x)*as1] : 0.f;
        bb[y][x] = base+y < k && col < n ? b[(base+y)*bs0+col*bs1] : 0.f;
        __syncthreads();
        #pragma unroll
        for (int j = 0; j < T; ++j) acc = __fmaf_rn(aa[y][j], bb[j][x], acc);
        __syncthreads();
    }
    if (row < m && col < n) c[row*n+col] = acc;
}
__global__ void timestep_embedding(const float* t, const float* f, float* e, int n) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n * 128) return;
    int row=i/128, col=i%128;
    float p = (t[row]*f[col])*1000.f;
    e[row*256+col] = cosf(p);
    e[row*256+128+col] = sinf(p);
}
__global__ void timestep_silu(const float* x, float* y, int n, bool derivative) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    float v=x[i], s=1.f/(1.f+expf(-v));
    y[i] = derivative ? s+(v*s)*(1.f-s) : v*s;
}
__global__ void timestep_dt(const float* de, const float* e, const float* f,
                            float* dt, int n) {
    int row = blockIdx.x * blockDim.x + threadIdx.x;
    if (row >= n) return;
    float result=0.f;
    for (int i=0; i<128; ++i) {
        float term=(-de[row*256+i]*e[row*256+128+i])
                  + de[row*256+128+i]*e[row*256+i];
        result += (term*1000.f)*f[i];
    }
    dt[row]=result;
}
void check(const torch::Tensor& x) {
    TORCH_CHECK(x.is_cuda() && x.scalar_type()==at::kFloat, "expected CUDA FP32");
}
}

torch::Tensor mm(torch::Tensor a, torch::Tensor b) {
    check(a); check(b);
    TORCH_CHECK(a.dim()==2 && b.dim()==2 && a.size(1)==b.size(0), "bad mm shape");
    TORCH_CHECK(a.device()==b.device(), "device mismatch");
    c10::cuda::CUDAGuard guard(a.device());
    auto c=torch::empty({a.size(0),b.size(1)},a.options());
    if (c.numel()) {
        dim3 threads(T,T), blocks((b.size(1)+T-1)/T,(a.size(0)+T-1)/T);
        timestep_mm<<<blocks,threads,0,at::cuda::getCurrentCUDAStream()>>>(
            a.data_ptr<float>(),b.data_ptr<float>(),c.data_ptr<float>(),
            a.size(0),b.size(1),a.size(1),a.stride(0),a.stride(1),b.stride(0),b.stride(1));
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return c;
}
torch::Tensor embedding(torch::Tensor t, torch::Tensor f) {
    check(t); check(f);
    TORCH_CHECK(t.dim()==1 && t.is_contiguous() && f.numel()==128 && f.is_contiguous(), "bad embedding shape");
    TORCH_CHECK(t.device()==f.device(), "device mismatch");
    c10::cuda::CUDAGuard guard(t.device());
    auto e=torch::empty({t.numel(),256},t.options());
    if (t.numel()) {
        timestep_embedding<<<(t.numel()*128+255)/256,256,0,at::cuda::getCurrentCUDAStream()>>>(t.data_ptr<float>(),f.data_ptr<float>(),e.data_ptr<float>(),t.numel());
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return e;
}
torch::Tensor unary(torch::Tensor x, bool derivative) {
    check(x); TORCH_CHECK(x.is_contiguous(), "expected contiguous unary input");
    c10::cuda::CUDAGuard guard(x.device());
    auto y=torch::empty_like(x);
    if (x.numel()) {
        timestep_silu<<<(x.numel()+255)/256,256,0,at::cuda::getCurrentCUDAStream()>>>(x.data_ptr<float>(),y.data_ptr<float>(),x.numel(),derivative);
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return y;
}
torch::Tensor timestep_grad(torch::Tensor de, torch::Tensor e, torch::Tensor f) {
    check(de); check(e); check(f);
    TORCH_CHECK(de.dim()==2 && de.size(1)==256 && e.sizes()==de.sizes() && f.numel()==128, "bad dt shape");
    TORCH_CHECK(de.is_contiguous() && e.is_contiguous() && f.is_contiguous(), "expected contiguous dt inputs");
    TORCH_CHECK(de.device()==e.device() && de.device()==f.device(), "device mismatch");
    c10::cuda::CUDAGuard guard(de.device());
    auto dt=torch::empty({de.size(0)},de.options());
    if (dt.numel()) {
        timestep_dt<<<(dt.numel()+127)/128,128,0,at::cuda::getCurrentCUDAStream()>>>(de.data_ptr<float>(),e.data_ptr<float>(),f.data_ptr<float>(),dt.data_ptr<float>(),dt.numel());
        C10_CUDA_KERNEL_LAUNCH_CHECK();
    }
    return dt;
}
PYBIND11_MODULE(TORCH_EXTENSION_NAME,m) {
    m.def("mm",&mm); m.def("embedding",&embedding);
    m.def("unary",&unary); m.def("timestep_grad",&timestep_grad);
}
