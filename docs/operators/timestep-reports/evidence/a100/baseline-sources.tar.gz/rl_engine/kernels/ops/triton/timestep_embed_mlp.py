# SPDX-License-Identifier: Apache-2.0
"""Triton FP32 IEEE dot primitives with fixed tiles and no atomic reductions."""

import torch
import triton as tr
import triton.language as tl
import triton.language.extra.cuda.libdevice as lib

from ..timestep_embed_mlp import TimestepEmbedMLPOp


@tr.jit
def _timestep_mm(A, B, C, M: tl.constexpr, N: tl.constexpr, K: tl.constexpr,
                 A0: tl.constexpr, A1: tl.constexpr, B0: tl.constexpr, B1: tl.constexpr):
    m = tl.program_id(0) * 16 + tl.arange(0, 16)
    n = tl.program_id(1) * 32 + tl.arange(0, 32)
    k = tl.arange(0, 32)
    acc = tl.full((16, 32), 0, tl.float32)
    for base in range(tr.cdiv(K, 32)):
        kk = base * 32 + k
        a = tl.load(A + m[:, None]*A0 + kk[None, :]*A1,
                    (m[:, None] < M) & (kk[None, :] < K), 0)
        b = tl.load(B + kk[:, None]*B0 + n[None, :]*B1,
                    (kk[:, None] < K) & (n[None, :] < N), 0)
        acc = tl.dot(a, b, acc, input_precision="ieee")
    tl.store(C + m[:, None]*N + n[None, :], acc,
             (m[:, None] < M) & (n[None, :] < N))


@tr.jit
def _timestep_embedding(T, F, E, N: tl.constexpr):
    i = tl.program_id(0)*256 + tl.arange(0, 256)
    row, col = i//128, i%128
    t = tl.load(T+row, row < N, 0)
    f = tl.load(F+col)
    p = (t*f)*1000.
    tl.store(E+row*256+col, lib.cos(p), row < N)
    tl.store(E+row*256+128+col, lib.sin(p), row < N)


@tr.jit
def _timestep_silu(X, Y, N: tl.constexpr, DERIVATIVE: tl.constexpr):
    i = tl.program_id(0)*256 + tl.arange(0, 256)
    x = tl.load(X+i, i < N, 0)
    s = lib.div_rn(1., 1. + lib.exp(-x))
    y = s + (x*s)*(1.-s) if DERIVATIVE else x*s
    tl.store(Y+i, y, i < N)


@tr.jit
def _timestep_dt(DE, E, F, DT):
    row = tl.program_id(0)
    i = tl.arange(0, 128)
    dc, ds = tl.load(DE+row*256+i), tl.load(DE+row*256+128+i)
    c, s = tl.load(E+row*256+i), tl.load(E+row*256+128+i)
    f = tl.load(F+i)
    dt = tl.sum(((-dc*s+ds*c)*1000.)*f, 0)
    tl.store(DT+row, dt)


class TritonPrimitives:
    def mm(self, a, b, trace):
        trace.kernels.append("triton._timestep_mm")
        m, k = a.shape
        n = b.shape[1]
        out = torch.empty((m, n), device=a.device, dtype=torch.float32)
        if m and n:
            _timestep_mm[(tr.cdiv(m, 16), tr.cdiv(n, 32))](
                a, b, out, m, n, k, *a.stride(), *b.stride(), num_warps=4,
                enable_fp_fusion=False)
        return out

    def embedding(self, t, f, trace):
        trace.kernels.append("triton._timestep_embedding")
        out = torch.empty((t.numel(), 256), device=t.device, dtype=torch.float32)
        if t.numel():
            _timestep_embedding[(tr.cdiv(t.numel()*128, 256),)](
                t, f, out, t.numel(), enable_fp_fusion=False)
        return out

    def unary(self, x, derivative, trace):
        trace.kernels.append("triton._timestep_silu_grad" if derivative else "triton._timestep_silu")
        out = torch.empty_like(x)
        if x.numel():
            _timestep_silu[(tr.cdiv(x.numel(), 256),)](
                x, out, x.numel(), derivative, enable_fp_fusion=False)
        return out

    def timestep_grad(self, de, e, f, trace):
        trace.kernels.append("triton._timestep_dt")
        out = torch.empty((de.shape[0],), device=de.device, dtype=torch.float32)
        if out.numel():
            _timestep_dt[(out.numel(),)](de, e, f, out, enable_fp_fusion=False)
        return out


class TritonTimestepEmbedMLPOp(TimestepEmbedMLPOp):
    def __init__(self, *, allow_fallback=False):
        super().__init__("triton", allow_fallback=allow_fallback)
